from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import bcrypt

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), nullable=False, default='student')  # admin, doctor, student, researcher
    institution = db.Column(db.String(200))
    department = db.Column(db.String(100))
    registration_number = db.Column(db.String(50))  # CRM, matrícula, etc.
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relacionamentos
    slides = db.relationship('Slide', backref='uploader', lazy=True)
    annotations = db.relationship('Annotation', backref='annotator', lazy=True)

    def __repr__(self):
        return f'<User {self.username}>'

    def set_password(self, password):
        """Hash e armazenar senha"""
        salt = bcrypt.gensalt()
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def check_password(self, password):
        """Verificar senha"""
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))

    def get_full_name(self):
        """Retornar nome completo"""
        return f"{self.first_name} {self.last_name}"

    def has_permission(self, permission):
        """Verificar se usuário tem permissão específica"""
        permissions = {
            'admin': ['view_all', 'edit_all', 'delete_all', 'manage_users', 'system_config'],
            'doctor': ['view_own', 'edit_own', 'delete_own', 'analyze_slides', 'create_annotations'],
            'researcher': ['view_own', 'edit_own', 'analyze_slides', 'create_annotations', 'export_data'],
            'student': ['view_own', 'create_annotations']
        }
        
        user_permissions = permissions.get(self.user_type, [])
        return permission in user_permissions

    def can_access_slide(self, slide):
        """Verificar se usuário pode acessar uma lâmina específica"""
        if self.user_type == 'admin':
            return True
        
        # Usuário pode acessar suas próprias lâminas
        if slide.uploaded_by == self.id:
            return True
        
        # TODO: Implementar lógica de compartilhamento de lâminas
        return False

    def to_dict(self, include_sensitive=False):
        """Converter para dicionário"""
        data = {
            'id': self.id,
            'username': self.username,
            'email': self.email if include_sensitive else None,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.get_full_name(),
            'user_type': self.user_type,
            'institution': self.institution,
            'department': self.department,
            'registration_number': self.registration_number if include_sensitive else None,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
        
        return {k: v for k, v in data.items() if v is not None}

class UserSession(db.Model):
    """Modelo para gerenciar sessões de usuário"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    session_token = db.Column(db.String(255), unique=True, nullable=False)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    
    user = db.relationship('User', backref='sessions')

    def __repr__(self):
        return f'<UserSession {self.session_token[:8]}...>'

    def is_expired(self):
        """Verificar se sessão expirou"""
        return datetime.utcnow() > self.expires_at

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'is_active': self.is_active
        }

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email
        }
