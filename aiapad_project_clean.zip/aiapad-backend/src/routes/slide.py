import os
import uuid
import json
from flask import Blueprint, request, jsonify, current_app, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
from src.models.slide import Slide, Annotation, AIAnalysis, db
from src.models.user import User
from src.utils.slide_processor import SlideProcessor
import openslide
from PIL import Image
import io

slide_bp = Blueprint('slide', __name__)

ALLOWED_EXTENSIONS = {'svs', 'tif', 'tiff', 'ndpi', 'scn', 'mrxs', 'vms', 'vmu'}
UPLOAD_FOLDER = 'uploads/slides'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_current_user():
    """Obter usuário atual autenticado"""
    current_user_id = get_jwt_identity()
    return User.query.get(current_user_id) if current_user_id else None

@slide_bp.route('/slides', methods=['GET'])
@jwt_required()
def get_slides():
    """Listar lâminas do usuário"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    # Admins podem ver todas as lâminas
    if current_user.user_type == 'admin':
        slides = Slide.query.all()
    else:
        # Outros usuários veem apenas suas lâminas
        slides = Slide.query.filter_by(uploaded_by=current_user.id).all()
    
    return jsonify([slide.to_dict() for slide in slides])

@slide_bp.route('/slides/<int:slide_id>', methods=['GET'])
@jwt_required()
def get_slide(slide_id):
    """Obter detalhes de uma lâmina específica"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    return jsonify(slide.to_dict())

@slide_bp.route('/slides/upload', methods=['POST'])
@jwt_required()
def upload_slide():
    """Upload de uma nova lâmina"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum arquivo enviado'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Tipo de arquivo não permitido'}), 400
    
    # Criar diretório de upload se não existir
    upload_path = os.path.join(current_app.root_path, '..', UPLOAD_FOLDER)
    os.makedirs(upload_path, exist_ok=True)
    
    # Gerar nome único para o arquivo
    file_extension = file.filename.rsplit('.', 1)[1].lower()
    unique_filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = os.path.join(upload_path, unique_filename)
    
    try:
        # Salvar arquivo
        file.save(file_path)
        
        # Processar metadados da lâmina
        processor = SlideProcessor()
        metadata = processor.extract_metadata(file_path)
        
        # Criar registro no banco de dados
        slide = Slide(
            filename=unique_filename,
            original_filename=file.filename,
            file_path=file_path,
            file_size=os.path.getsize(file_path),
            scanner_type=metadata.get('scanner_type'),
            stain_type=metadata.get('stain_type'),
            width=metadata.get('width'),
            height=metadata.get('height'),
            levels=metadata.get('levels'),
            mpp_x=metadata.get('mpp_x'),
            mpp_y=metadata.get('mpp_y'),
            uploaded_by=current_user.id,
            status='ready'
        )
        
        db.session.add(slide)
        db.session.commit()
        
        return jsonify(slide.to_dict()), 201
        
    except Exception as e:
        # Remover arquivo se houve erro
        if os.path.exists(file_path):
            os.remove(file_path)
        return jsonify({'error': f'Erro ao processar arquivo: {str(e)}'}), 500

@slide_bp.route('/slides/<int:slide_id>/tile/<int:level>/<int:x>/<int:y>/<int:width>/<int:height>', methods=['GET'])
@jwt_required()
def get_tile(slide_id, level, x, y, width, height):
    """Obter um tile específico da lâmina para visualização"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    try:
        # Abrir lâmina com OpenSlide
        slide_obj = openslide.OpenSlide(slide.file_path)
        
        # Extrair tile
        tile = slide_obj.read_region((x, y), level, (width, height))
        
        # Converter para RGB (remover canal alpha)
        tile = tile.convert('RGB')
        
        # Converter para bytes
        img_io = io.BytesIO()
        tile.save(img_io, 'JPEG', quality=85)
        img_io.seek(0)
        
        slide_obj.close()
        
        return send_file(img_io, mimetype='image/jpeg')
        
    except Exception as e:
        return jsonify({'error': f'Erro ao gerar tile: {str(e)}'}), 500

@slide_bp.route('/slides/<int:slide_id>/thumbnail', methods=['GET'])
@jwt_required()
def get_thumbnail(slide_id):
    """Obter thumbnail da lâmina"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    try:
        slide_obj = openslide.OpenSlide(slide.file_path)
        
        # Obter thumbnail do nível mais baixo
        level = slide_obj.level_count - 1
        thumbnail = slide_obj.read_region((0, 0), level, slide_obj.level_dimensions[level])
        thumbnail = thumbnail.convert('RGB')
        
        # Redimensionar se necessário
        max_size = (300, 300)
        thumbnail.thumbnail(max_size, Image.Resampling.LANCZOS)
        
        img_io = io.BytesIO()
        thumbnail.save(img_io, 'JPEG', quality=85)
        img_io.seek(0)
        
        slide_obj.close()
        
        return send_file(img_io, mimetype='image/jpeg')
        
    except Exception as e:
        return jsonify({'error': f'Erro ao gerar thumbnail: {str(e)}'}), 500

@slide_bp.route('/slides/<int:slide_id>/annotations', methods=['GET'])
@jwt_required()
def get_annotations(slide_id):
    """Obter todas as anotações de uma lâmina"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    annotations = Annotation.query.filter_by(slide_id=slide_id).all()
    return jsonify([annotation.to_dict() for annotation in annotations])

@slide_bp.route('/slides/<int:slide_id>/annotations', methods=['POST'])
@jwt_required()
def create_annotation(slide_id):
    """Criar uma nova anotação"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Verificar permissão para criar anotações
    if not current_user.has_permission('create_annotations'):
        return jsonify({'error': 'Permissão insuficiente para criar anotações'}), 403
    
    data = request.json
    
    annotation = Annotation(
        slide_id=slide_id,
        user_id=current_user.id,
        x=data['x'],
        y=data['y'],
        width=data.get('width'),
        height=data.get('height'),
        annotation_type=data['annotation_type'],
        label=data.get('label'),
        description=data.get('description'),
        coordinates=json.dumps(data.get('coordinates')) if data.get('coordinates') else None
    )
    
    db.session.add(annotation)
    db.session.commit()
    
    return jsonify(annotation.to_dict()), 201

@slide_bp.route('/slides/<int:slide_id>/analyze', methods=['POST'])
@jwt_required()
def analyze_slide(slide_id):
    """Iniciar análise de IA em uma lâmina"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Verificar permissão para analisar lâminas
    if not current_user.has_permission('analyze_slides'):
        return jsonify({'error': 'Permissão insuficiente para analisar lâminas'}), 403
    
    data = request.json
    analysis_type = data.get('analysis_type', 'disease_detection')
    
    # Criar registro de análise
    analysis = AIAnalysis(
        slide_id=slide_id,
        analysis_type=analysis_type,
        model_name='basic_classifier',
        status='pending'
    )
    
    db.session.add(analysis)
    db.session.commit()
    
    # TODO: Implementar processamento assíncrono
    # Por enquanto, retorna um resultado simulado
    analysis.status = 'completed'
    analysis.confidence = 0.85
    analysis.result = json.dumps({
        'prediction': 'Normal tissue',
        'confidence': 0.85,
        'regions_of_interest': []
    })
    analysis.processing_time = 2.5
    
    db.session.commit()
    
    return jsonify(analysis.to_dict()), 201

@slide_bp.route('/slides/<int:slide_id>/analyses', methods=['GET'])
@jwt_required()
def get_analyses(slide_id):
    """Obter todas as análises de IA de uma lâmina"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    analyses = AIAnalysis.query.filter_by(slide_id=slide_id).all()
    return jsonify([analysis.to_dict() for analysis in analyses])

@slide_bp.route('/slides/<int:slide_id>', methods=['DELETE'])
@jwt_required()
def delete_slide(slide_id):
    """Deletar uma lâmina"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    slide = Slide.query.get_or_404(slide_id)
    
    # Verificar permissão de acesso
    if not current_user.can_access_slide(slide):
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Verificar permissão para deletar
    if slide.uploaded_by != current_user.id and not current_user.has_permission('delete_all'):
        return jsonify({'error': 'Permissão insuficiente para deletar esta lâmina'}), 403
    
    try:
        # Remover arquivo físico
        if os.path.exists(slide.file_path):
            os.remove(slide.file_path)
        
        # Remover do banco de dados (cascata remove anotações e análises)
        db.session.delete(slide)
        db.session.commit()
        
        return '', 204
        
    except Exception as e:
        return jsonify({'error': f'Erro ao deletar lâmina: {str(e)}'}), 500

